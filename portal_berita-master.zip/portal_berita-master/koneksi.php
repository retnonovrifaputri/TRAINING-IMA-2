<?php
// Koneksi Ke Database
$server = "localhost";
$server_username = "root";
$server_password = "root";
$database_name =  "db_portal_berita";
$conn = new Mysqli($server, $server_username, $server_password, $database_name);
